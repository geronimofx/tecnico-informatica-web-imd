class Personagem {
    
    atacar() {
        console.log("Não recebi dano.")
    }

}

class Guerreiro extends Personagem {

    atacar() {
        console.log("Recebi 10 de dano.");
    }

}

class Arqueiro extends Personagem {

    atacar() {
        console.log("Recebi 20 de dano.");
    }
    
}

function atacarPersonagem(fulano: Personagem) {
    fulano.atacar();
}

let p1 = new Guerreiro();
let p2 = new Arqueiro();

atacarPersonagem(p1);
atacarPersonagem(p2);
var Jogador = /** @class */ (function () {
    function Jogador() {
    }
    Jogador.prototype.mover = function () {
        console.log("Jogador se movendo.");
    };
    return Jogador;
}());
var Volante = /** @class */ (function () {
    function Volante() {
    }
    Volante.prototype.mover = function () {
        console.log("Volante girando.");
    };
    return Volante;
}());
var a = new Jogador();
var b = new Volante();
a.mover();
b.mover();

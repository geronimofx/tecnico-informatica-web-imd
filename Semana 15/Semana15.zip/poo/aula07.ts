class Animal {

    public grupo: string = "nao inicializado";

}

class Cachorro extends Animal {

    constructor() {
        super();
        this.grupo = "mamífero";
    }

}

let c = new Cachorro();
console.log(c.grupo);
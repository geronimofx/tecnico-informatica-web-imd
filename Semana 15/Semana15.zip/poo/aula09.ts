interface Controlavel {

    mover() : void;

}

class Jogador implements Controlavel {

    mover() : void {
        console.log("Jogador se movendo.");
    }

}

class Volante implements Controlavel {

    mover() {
        console.log("Volante girando.");
    }

}

let a = new Jogador();
let b = new Volante();

a.mover();
b.mover();
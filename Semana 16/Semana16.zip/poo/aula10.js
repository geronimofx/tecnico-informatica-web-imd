function adicionar_valor(inicial, adicional) {
    if (adicional <= 0) {
        throw new Error("Somente valores positivos devem ser adicionados ao valor inicial.");
    }
    return inicial + adicional;
}
var x = -1;
try {
    x = adicionar_valor(100, 10);
}
catch (e) {
    console.log(e);
}
console.log("resultado é ", x);

export default class Pessoa {
    public falar() {
        console.log("Oi");
    }
}
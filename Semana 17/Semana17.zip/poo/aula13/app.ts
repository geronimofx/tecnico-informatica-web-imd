import Pessoa from './pessoa';

let pessoa = new Pessoa(); 
pessoa.falar()